-- Dark FPS GUI Shell
-- Place this LocalScript in StarterPlayer > StarterPlayerScripts.
-- UI-only demo. Buttons and toggles are visual placeholders.

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local old = playerGui:FindFirstChild("DarkFpsGui")
if old then old:Destroy() end

local C = {
    bg = Color3.fromRGB(12, 13, 15),
    panel = Color3.fromRGB(17, 18, 20),
    panel2 = Color3.fromRGB(22, 23, 25),
    border = Color3.fromRGB(42, 44, 46),
    text = Color3.fromRGB(220, 222, 224),
    muted = Color3.fromRGB(120, 124, 128),
    green = Color3.fromRGB(151, 190, 68),
    greenDim = Color3.fromRGB(49, 64, 31),
}

local function make(className, props, parent)
    local obj = Instance.new(className)
    for k, v in pairs(props or {}) do obj[k] = v end
    obj.Parent = parent
    return obj
end

local function corner(parent, radius)
    make("UICorner", {CornerRadius = UDim.new(0, radius or 3)}, parent)
end

local function stroke(parent, color, thickness)
    make("UIStroke", {Color = color or C.border, Thickness = thickness or 1, Transparency = 0}, parent)
end

local gui = make("ScreenGui", {
    Name = "DarkFpsGui",
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, playerGui)

local toggleButton = make("TextButton", {
    Name = "MenuToggle",
    Size = UDim2.fromOffset(58, 26),
    Position = UDim2.new(0, 16, 0.5, -13),
    BackgroundColor3 = C.bg,
    BorderSizePixel = 0,
    Text = "MENU",
    TextColor3 = C.text,
    TextSize = 10,
    Font = Enum.Font.GothamSemibold,
    AutoButtonColor = false,
}, gui)
corner(toggleButton, 3)
stroke(toggleButton)

local window = make("Frame", {
    Name = "Window",
    Size = UDim2.fromOffset(610, 390),
    Position = UDim2.new(0, 88, 0.5, -195),
    BackgroundColor3 = C.bg,
    BorderSizePixel = 0,
    Visible = true,
}, gui)
corner(window, 4)
stroke(window, C.border, 1)

local scale = make("UIScale", {Scale = 1}, window)
local function updateScale()
    local cam = workspace.CurrentCamera
    if not cam then return end
    local v = cam.ViewportSize
    if v.X < 700 then
        scale.Scale = math.clamp(math.min((v.X - 24) / 610, (v.Y - 70) / 390), 0.55, 0.9)
        window.Position = UDim2.new(0.5, -305 * scale.Scale, 0.5, -195 * scale.Scale)
    else
        scale.Scale = 1
        window.Position = UDim2.new(0, 88, 0.5, -195)
    end
end
updateScale()
if workspace.CurrentCamera then
    workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(updateScale)
end

-- Narrow icon rail, similar to the reference layout.
local rail = make("Frame", {
    Name = "IconRail",
    Size = UDim2.new(0, 43, 1, 0),
    BackgroundColor3 = C.panel,
    BorderSizePixel = 0,
}, window)
make("Frame", {
    Size = UDim2.new(0, 1, 1, -16),
    Position = UDim2.new(1, -1, 0, 8),
    BackgroundColor3 = C.border,
    BorderSizePixel = 0,
}, rail)

local brand = make("TextLabel", {
    Size = UDim2.new(1, 0, 0, 42),
    BackgroundTransparency = 1,
    Text = "◈",
    TextColor3 = C.green,
    TextSize = 18,
    Font = Enum.Font.GothamBold,
}, rail)

local content = make("Frame", {
    Name = "Content",
    Position = UDim2.new(0, 44, 0, 0),
    Size = UDim2.new(1, -44, 1, 0),
    BackgroundTransparency = 1,
}, window)

local topbar = make("Frame", {
    Size = UDim2.new(1, 0, 0, 42),
    BackgroundTransparency = 1,
}, content)
local title = make("TextLabel", {
    Position = UDim2.fromOffset(16, 0),
    Size = UDim2.new(1, -70, 1, 0),
    BackgroundTransparency = 1,
    Text = "CONTROL PANEL",
    TextColor3 = C.text,
    TextSize = 11,
    Font = Enum.Font.GothamSemibold,
    TextXAlignment = Enum.TextXAlignment.Left,
}, topbar)
make("Frame", {
    Position = UDim2.new(0, 14, 1, -1),
    Size = UDim2.new(1, -28, 0, 1),
    BackgroundColor3 = C.border,
    BorderSizePixel = 0,
}, topbar)

local close = make("TextButton", {
    Position = UDim2.new(1, -35, 0, 10),
    Size = UDim2.fromOffset(20, 20),
    BackgroundColor3 = C.panel2,
    BorderSizePixel = 0,
    Text = "×",
    TextColor3 = C.muted,
    TextSize = 16,
    Font = Enum.Font.Gotham,
    AutoButtonColor = false,
}, topbar)
corner(close, 3)

local tabNames = {"AIM", "VISUALS", "PLAYER", "WORLD", "SETTINGS"}
local tabIcons = {"⌁", "◉", "♙", "⌂", "⚙"}
local tabButtons = {}
local currentTab = "AIM"

local tabRail = make("Frame", {
    Position = UDim2.fromOffset(0, 48),
    Size = UDim2.new(1, 0, 1, -56),
    BackgroundTransparency = 1,
}, rail)
make("UIListLayout", {
    Padding = UDim.new(0, 5),
    HorizontalAlignment = Enum.HorizontalAlignment.Center,
    SortOrder = Enum.SortOrder.LayoutOrder,
}, tabRail)

local body = make("Frame", {
    Name = "Body",
    Position = UDim2.fromOffset(14, 52),
    Size = UDim2.new(1, -28, 1, -64),
    BackgroundTransparency = 1,
}, content)

local function addText(parent, text, size, color, bold)
    return make("TextLabel", {
        Size = size,
        BackgroundTransparency = 1,
        Text = text,
        TextColor3 = color or C.text,
        TextSize = 10,
        Font = bold and Enum.Font.GothamSemibold or Enum.Font.Gotham,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextYAlignment = Enum.TextYAlignment.Center,
    }, parent)
end

local function createSection(parent, name, x, y, w, h)
    local section = make("Frame", {
        Position = UDim2.fromOffset(x, y),
        Size = UDim2.fromOffset(w, h),
        BackgroundColor3 = C.panel,
        BorderSizePixel = 0,
    }, parent)
    corner(section, 3)
    stroke(section, C.border, 1)
    local header = make("Frame", {
        Size = UDim2.new(1, 0, 0, 27),
        BackgroundColor3 = C.panel2,
        BorderSizePixel = 0,
    }, section)
    corner(header, 3)
    addText(header, "  " .. name, UDim2.new(1, -12, 1, 0), C.text, true)
    make("Frame", {
        Position = UDim2.new(0, 0, 0, 26),
        Size = UDim2.new(1, 0, 0, 1),
        BackgroundColor3 = C.border,
        BorderSizePixel = 0,
    }, section)
    return section
end

local function addToggle(parent, label, y, default)
    addText(parent, label, UDim2.new(1, -52, 0, 24), C.muted, false).Position = UDim2.fromOffset(10, y)
    local b = make("TextButton", {
        Position = UDim2.new(1, -43, 0, y + 5),
        Size = UDim2.fromOffset(31, 14),
        BackgroundColor3 = default and C.greenDim or C.panel2,
        BorderSizePixel = 0,
        Text = "",
        AutoButtonColor = false,
    }, parent)
    corner(b, 7)
    local knob = make("Frame", {
        Position = default and UDim2.new(1, -12, 0, 2) or UDim2.fromOffset(2, 2),
        Size = UDim2.fromOffset(10, 10),
        BackgroundColor3 = default and C.green or C.muted,
        BorderSizePixel = 0,
    }, b)
    corner(knob, 6)
    local on = default
    b.Activated:Connect(function()
        on = not on
        TweenService:Create(b, TweenInfo.new(0.12), {
            BackgroundColor3 = on and C.greenDim or C.panel2
        }):Play()
        TweenService:Create(knob, TweenInfo.new(0.12), {
            Position = on and UDim2.new(1, -12, 0, 2) or UDim2.fromOffset(2, 2),
            BackgroundColor3 = on and C.green or C.muted
        }):Play()
    end)
end

local function addSlider(parent, label, y, value)
    addText(parent, label, UDim2.new(1, -50, 0, 18), C.muted, false).Position = UDim2.fromOffset(10, y)
    addText(parent, tostring(value) .. "%", UDim2.fromOffset(35, 18), C.green, true).Position = UDim2.new(1, -45, 0, y)
    local bar = make("Frame", {
        Position = UDim2.fromOffset(10, y + 20),
        Size = UDim2.new(1, -20, 0, 4),
        BackgroundColor3 = C.panel2,
        BorderSizePixel = 0,
    }, parent)
    corner(bar, 2)
    local fill = make("Frame", {
        Size = UDim2.new(value / 100, 0, 1, 0),
        BackgroundColor3 = C.green,
        BorderSizePixel = 0,
    }, bar)
    corner(fill, 2)
end

local function addDropdown(parent, label, value, y)
    addText(parent, label, UDim2.new(0.5, -8, 0, 26), C.muted, false).Position = UDim2.fromOffset(10, y)
    local b = make("TextButton", {
        Position = UDim2.new(0.5, 0, 0, y + 3),
        Size = UDim2.new(0.5, -10, 0, 21),
        BackgroundColor3 = C.panel2,
        BorderSizePixel = 0,
        Text = value .. "  ▾",
        TextColor3 = C.text,
        TextSize = 9,
        Font = Enum.Font.Gotham,
        AutoButtonColor = false,
    }, parent)
    corner(b, 2)
    stroke(b, C.border)
    b.Activated:Connect(function()
        local oldValue = b.Text
        b.Text = oldValue:find("Default") and "Custom  ▾" or "Default  ▾"
    end)
end

local function clearBody()
    for _, child in ipairs(body:GetChildren()) do child:Destroy() end
end

local function buildTab(name)
    clearBody()
    currentTab = name
    local leftW, rightW = 252, 252
    local gap = 12
    local bodyWidth = math.max(300, body.AbsoluteSize.X)
    leftW = math.floor((bodyWidth - gap) / 2)
    rightW = leftW

    if name == "AIM" then
        local a = createSection(body, "ASSIST", 0, 0, leftW, 152)
        addToggle(a, "Enable", 34, false)
        addToggle(a, "Draw FOV", 60, true)
        addToggle(a, "Show target", 86, false)
        addSlider(a, "FOV radius", 112, 45)

        local b = createSection(body, "TARGET", leftW + gap, 0, rightW, 152)
        addDropdown(b, "Target part", "Default", 35)
        addDropdown(b, "Priority", "Distance", 67)
        addToggle(b, "Visible only", 100, true)

        local c = createSection(body, "INPUT", 0, 164, leftW, 142)
        addToggle(c, "Hold to activate", 34, false)
        addDropdown(c, "Activation key", "Default", 67)
        addSlider(c, "Smoothing", 100, 35)

        local d = createSection(body, "STATUS", leftW + gap, 164, rightW, 142)
        addText(d, "UI preview only", UDim2.new(1, -20, 0, 24), C.green, true).Position = UDim2.fromOffset(10, 37)
        addText(d, "Connect your own permitted", UDim2.new(1, -20, 0, 18), C.muted, false).Position = UDim2.fromOffset(10, 62)
        addText(d, "game systems here.", UDim2.new(1, -20, 0, 18), C.muted, false).Position = UDim2.fromOffset(10, 80)
    elseif name == "VISUALS" then
        local a = createSection(body, "DISPLAY", 0, 0, leftW, 152)
        addToggle(a, "Enable overlay", 34, false)
        addToggle(a, "Names", 60, true)
        addToggle(a, "Health bars", 86, true)
        addToggle(a, "Distance labels", 112, false)
        local b = createSection(body, "STYLE", leftW + gap, 0, rightW, 152)
        addDropdown(b, "Accent", "Green", 35)
        addDropdown(b, "Text size", "Small", 67)
        addToggle(b, "Outline", 100, true)
        local c = createSection(body, "PREVIEW", 0, 164, leftW, 142)
        addText(c, "Visual settings preview", UDim2.new(1, -20, 0, 25), C.text, true).Position = UDim2.fromOffset(10, 38)
        addText(c, "No game-world overlay is connected.", UDim2.new(1, -20, 0, 18), C.muted, false).Position = UDim2.fromOffset(10, 66)
        local d = createSection(body, "OPTIONS", leftW + gap, 164, rightW, 142)
        addToggle(d, "Fade inactive items", 34, true)
        addToggle(d, "Show indicators", 60, true)
        addToggle(d, "Compact labels", 86, false)
    elseif name == "PLAYER" then
        local a = createSection(body, "MOVEMENT", 0, 0, leftW, 152)
        addToggle(a, "Sprint setting", 34, false)
        addToggle(a, "Camera bob", 60, true)
        addSlider(a, "Field of view", 92, 50)
        local b = createSection(body, "PREFERENCES", leftW + gap, 0, rightW, 152)
        addToggle(b, "First person", 34, true)
        addToggle(b, "Reduced motion", 60, false)
        addDropdown(b, "Crosshair", "Default", 92)
        local c = createSection(body, "CONTROLS", 0, 164, leftW, 142)
        addDropdown(c, "Interact key", "Default", 38)
        addToggle(c, "Touch hints", 70, true)
        local d = createSection(body, "INFO", leftW + gap, 164, rightW, 142)
        addText(d, "Preference placeholders", UDim2.new(1, -20, 0, 22), C.green, true).Position = UDim2.fromOffset(10, 38)
        addText(d, "These do not change other games.", UDim2.new(1, -20, 0, 20), C.muted, false).Position = UDim2.fromOffset(10, 64)
    elseif name == "WORLD" then
        local a = createSection(body, "ENVIRONMENT", 0, 0, leftW, 152)
        addToggle(a, "Color correction", 34, false)
        addToggle(a, "Reduce effects", 60, false)
        addSlider(a, "Brightness", 92, 50)
        local b = createSection(body, "AUDIO", leftW + gap, 0, rightW, 152)
        addToggle(b, "UI sounds", 34, true)
        addToggle(b, "Mute menu sounds", 60, false)
        addSlider(b, "Volume", 92, 65)
        local c = createSection(body, "ACCESSIBILITY", 0, 164, leftW, 142)
        addToggle(c, "High contrast", 34, false)
        addToggle(c, "Larger text", 60, false)
        local d = createSection(body, "NOTE", leftW + gap, 164, rightW, 142)
        addText(d, "Local UI preferences only", UDim2.new(1, -20, 0, 22), C.green, true).Position = UDim2.fromOffset(10, 38)
        addText(d, "No changes are made to Rivals.", UDim2.new(1, -20, 0, 20), C.muted, false).Position = UDim2.fromOffset(10, 64)
    else
        local a = createSection(body, "INTERFACE", 0, 0, leftW, 152)
        addToggle(a, "Remember position", 34, true)
        addToggle(a, "Show menu button", 60, true)
        addToggle(a, "Animations", 86, true)
        addDropdown(a, "Scale", "Default", 112)
        local b = createSection(body, "THEME", leftW + gap, 0, rightW, 152)
        addDropdown(b, "Theme", "Dark", 35)
        addDropdown(b, "Accent color", "Green", 67)
        addToggle(b, "Thin borders", 100, true)
        local c = createSection(body, "ABOUT", 0, 164, leftW, 142)
        addText(c, "DARK FPS UI", UDim2.new(1, -20, 0, 24), C.text, true).Position = UDim2.fromOffset(10, 38)
        addText(c, "Standalone Roblox Studio interface", UDim2.new(1, -20, 0, 18), C.muted, false).Position = UDim2.fromOffset(10, 65)
        local d = createSection(body, "ACTIONS", leftW + gap, 164, rightW, 142)
        local reset = make("TextButton", {
            Position = UDim2.fromOffset(10, 42),
            Size = UDim2.new(1, -20, 0, 27),
            BackgroundColor3 = C.panel2,
            BorderSizePixel = 0,
            Text = "Reset visual layout",
            TextColor3 = C.text,
            TextSize = 10,
            Font = Enum.Font.Gotham,
            AutoButtonColor = false,
        }, d)
        corner(reset, 3)
        stroke(reset)
        reset.Activated:Connect(function()
            buildTab("SETTINGS")
        end)
    end

    for tabName, button in pairs(tabButtons) do
        local selected = tabName == name
        button.BackgroundColor3 = selected and C.greenDim or C.panel
        button.TextColor3 = selected and C.green or C.muted
    end
end

for i, name in ipairs(tabNames) do
    local button = make("TextButton", {
        Name = name .. "Tab",
        LayoutOrder = i,
        Size = UDim2.fromOffset(31, 29),
        BackgroundColor3 = C.panel,
        BorderSizePixel = 0,
        Text = tabIcons[i],
        TextColor3 = C.muted,
        TextSize = 16,
        Font = Enum.Font.Gotham,
        AutoButtonColor = false,
    }, tabRail)
    corner(button, 3)
    tabButtons[name] = button
    button.Activated:Connect(function()
        buildTab(name)
    end)
end

-- Drag window from the top bar.
local dragging, dragStart, startPos
topbar.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = window.Position
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then dragging = false end
        end)
    end
end)
UserInputService.InputChanged:Connect(function(input)
    if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
        local delta = input.Position - dragStart
        window.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end
end)

local function setVisible(visible)
    if visible then
        window.Visible = true
        window.BackgroundTransparency = 1
        TweenService:Create(window, TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            BackgroundTransparency = 0
        }):Play()
    else
        window.Visible = false
    end
end

toggleButton.Activated:Connect(function()
    setVisible(not window.Visible)
end)
close.Activated:Connect(function()
    setVisible(false)
end)

buildTab("AIM")
