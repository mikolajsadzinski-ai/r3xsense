# Dark FPS GUI Shell (Roblox Studio)

A standalone Roblox Studio UI shell inspired by the reference video's visual style:
- compact near-black window
- narrow vertical icon rail
- small labels and dense two-column settings
- subtle green selection accents
- draggable window and animated tab switching
- PC and touch-friendly open/close button

This is UI-only. The feature panels are placeholders and do not implement cheats, exploit APIs, or interact with Roblox Rivals.

## Install
1. Open your Roblox Studio place.
2. In `StarterPlayer > StarterPlayerScripts`, create a `LocalScript` named `Main.client.lua`.
3. Copy the contents of `src/Client/Main.client.lua` into it.
4. Press Play. Use the small `MENU` button to hide/show the window.

The UI is built in code so you don't need to create every Instance manually.
